// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "StateMachine.h"
#include "Containers/Queue.h"
#include "FoodActor.h"
#include "GOAPAction.h"
#include "GOAPActor.generated.h"

UCLASS()
class FIT3094_A2_CODE_API AGOAPActor : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	enum Actor_States
	{

		State_Nothing,
		State_Idle,
		State_Move,
		State_Action

	};

	const float Tolerance = 20;
	int health;
	int healthThreshold;
	float MoveSpeed;

	AGOAPActor();
	


protected:

	StateMachine<Actor_States, AGOAPActor>* actionStateMachine;
	// A list of all availaile actions agent can perform
	TSet<GOAPAction*> availableActions;
	TQueue<GOAPAction*> currentActions;
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;


	// State Machine function
	void OnIdleEnter();
	void OnIdleUpdate(float DeltaTime);
	void OnIdleExit();

	// State Machine function
	void OnMoveEnter();
	void OnMoveUpdate(float DeltaTime);
	void OnMoveExit();
	// State Machine function
	void OnActionEnter();
	void OnActionUpdate(float DeltaTime);
	void OnActionExit();

	virtual TMap<FString, bool> getWorldStates();
	virtual TMap<FString, bool> createGoalState();

	virtual void onPlanFailed(TMap<FString, bool> FailedGoalState);

	virtual void onPlanAborted(GOAPAction* FailedAction);

	// decrease health is for every agent so put in base agent
	void decreaseHealth();
	
public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;
	

};
