// Fill out your copyright notice in the Description page of Project Settings.


#include "GOAPActor.h"
#include "GOAPPlanner.h"
#include "FoodActor.h"
#include "Kismet/KismetSystemLibrary.h"


// Sets default values
AGOAPActor::AGOAPActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	MoveSpeed = 1000;
	PrimaryActorTick.bCanEverTick = true;
	actionStateMachine = new StateMachine<Actor_States, AGOAPActor>(this, State_Nothing);
	actionStateMachine->RegisterState(State_Idle, &AGOAPActor::OnIdleEnter, &AGOAPActor::OnIdleUpdate, &AGOAPActor::OnIdleExit);
	actionStateMachine->RegisterState(State_Action, &AGOAPActor::OnActionEnter, &AGOAPActor::OnActionUpdate, &AGOAPActor::OnActionExit);
	actionStateMachine->RegisterState(State_Move, &AGOAPActor::OnMoveEnter, &AGOAPActor::OnMoveUpdate, &AGOAPActor::OnMoveExit);
	actionStateMachine->ChangeState(State_Idle);

}

// Called when the game starts or when spawned
void AGOAPActor::BeginPlay()
{
	Super::BeginPlay();

}

// Called every frame
void AGOAPActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	
	actionStateMachine->Tick(DeltaTime);



}

void AGOAPActor::OnIdleEnter()
{

}
void AGOAPActor::OnIdleUpdate(float DeltaTime)
{
	// Planning at this stage
	TMap<FString, bool> WorldState = getWorldStates();
	//Get Desired Goal state
	TMap<FString, bool> GoalState = createGoalState();

	if (GOAPPlanner::plan(this, availableActions, currentActions, WorldState, GoalState))
	{
	
		
		UE_LOG(LogTemp, Warning, TEXT("GOAP Agent Class: Plan has been found"));


		actionStateMachine->ChangeState(State_Action);
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("GOAP Agent Class: NO PLAN found!!!!!!!!!!"));

	}

}

void AGOAPActor::OnIdleExit()
{

}
void AGOAPActor::OnMoveEnter()
{
	// enter into move state check to ensure we can move
	// if no actions return to idle immediately
	if (currentActions.IsEmpty())
	{
		actionStateMachine->ChangeState(State_Idle);
		return;
	}

	GOAPAction* currentAction = *currentActions.Peek();


	// if current action requires an innrange check the target is null return to planning
	if (currentAction->requiresInRange() && currentAction->target == nullptr)
	{
		actionStateMachine->ChangeState(State_Idle);
	}
}

void AGOAPActor::OnMoveUpdate(float DeltaTime)
{

	GOAPAction* currentAction = *currentActions.Peek();
	
	// This is a direct move example
	FVector Direction = currentAction->target->GetActorLocation() - GetActorLocation();
	Direction.Normalize();

	FVector NewPos = GetActorLocation() + Direction * MoveSpeed *DeltaTime;

	if (FVector::Dist(NewPos, currentAction->target->GetActorLocation()) <= Tolerance)
	{
		NewPos = currentAction->target->GetActorLocation();

		currentAction->setInRange(true);

		actionStateMachine->ChangeState(State_Action);
	}
	SetActorLocation(NewPos);

}
void AGOAPActor::OnMoveExit()
{

}
void AGOAPActor::OnActionEnter()
{

}
void AGOAPActor::OnActionUpdate(float DeltaTime)
{
	if (currentActions.IsEmpty())
	{
		actionStateMachine->ChangeState(State_Idle);
		return;
	}

	//Check to see if our current action is finished
	GOAPAction* currentAction = *currentActions.Peek();

	if (currentAction->isActionDone())
	{
		currentActions.Dequeue(currentAction);
	}
	if (!currentActions.IsEmpty())
	{
		currentAction = *currentActions.Peek();
		//Check to see if we need to be within range for an action
		
		bool inRange = currentAction->requiresInRange() ? currentAction->isInRange() : true;
		
		if (inRange)
		{
			
			bool isActionSuccessful = currentAction->performAction(this);
			//UE_LOG(LogTemp, Warning, TEXT("GOAP Agent Class: Action Performed"));

			//if we failed change to idle state
			if (!isActionSuccessful)
			{
				actionStateMachine->ChangeState(State_Idle);
				onPlanAborted(currentAction);
			}
		}
		else
		{
			// perform move action if we are not in range of target
			actionStateMachine->ChangeState(State_Move);
		}
	}
	else
	{
		//no action remain, move to idle state
		actionStateMachine->ChangeState(State_Idle);
	}
}
void AGOAPActor::OnActionExit()
{

}

TMap<FString, bool> AGOAPActor::getWorldStates()
{

	TMap<FString, bool> CurrentWorldState;
	return CurrentWorldState;
}



TMap<FString, bool> AGOAPActor::createGoalState()
{
	TMap<FString, bool> GoalState;
	return GoalState;
}

void AGOAPActor::onPlanAborted(GOAPAction* FailedAction)
{
	
}
void AGOAPActor::onPlanFailed(TMap<FString, bool> FailedGoalState)
{
}

void AGOAPActor::decreaseHealth()
{
	health--;

	if (health <= 0)
	{
		Destroy();
	}
}
