// Fill out your copyright notice in the Description page of Project Settings.


#include "GOAPPlanner.h"
#include "GOAPAction.h"
#include  "GOAPActor.h"
GOAPPlanner::GOAPPlanner()
{
}

GOAPPlanner::~GOAPPlanner()
{
}


bool GOAPPlanner::plan(AGOAPActor* Agent, const TSet<GOAPAction*>& availableActions, TQueue<GOAPAction*>& PlannedActions, TMap<FString, bool> WorldState, TMap<FString, bool> GoalState)
{

	// start of planning we create an array to hold all nodes generated during planning
	TArray<GOAPNode*> AllNodes;

	for (auto Action : availableActions)
	{
		Action->doReset();
	}
	// empty plannedaction queue
	PlannedActions.Empty();

	
	TSet<GOAPAction*> UsableActions;
	// fetch usable actions
	for (auto Action : availableActions)
	{
		if (Action->checkProceduralPrecondition(Agent))
		{
			UsableActions.Add(Action);
		}
	}

	TArray<GOAPNode*> GoalNodes;

	GOAPNode* Start = new GOAPNode;
	Start->Parent = nullptr;
	Start->RunningCost = 0;
	Start->State = WorldState;
	Start->Action = nullptr;
	
	bool isSuccessful = buildGraphRecursive(AllNodes, Start, GoalNodes, availableActions, GoalState);
	
	//check for success
	//if not successful then return immediate
	if (!isSuccessful)
	{
		UE_LOG(LogTemp, Warning, TEXT("GOAPPALNNER: NO PLAN FOUND"));
		return false;
	}

	// just use for comparing 

	//if there is higher priority action, perform it first and removes other to avoid loop 

	
	//get cheapest goal
	GOAPNode* CheapestNode = nullptr;
	for (auto Node : GoalNodes)
	{
		if (CheapestNode)
		{
			if (Node->RunningCost < CheapestNode->RunningCost)
			{
				CheapestNode = Node;
			}

		}
		else
		{
			CheapestNode = Node;
		}
	}
	TArray <GOAPAction * > Results;
	GOAPNode* CurrentNode = CheapestNode;
	//check whether there is different priority inside action, if did, push to results base on that
	bool hasPriority = false;
	GOAPAction* priorityAction = nullptr;

	
	while (CurrentNode)
	{
		if (CurrentNode->Action)
		{

			Results.Insert(CurrentNode->Action,0);

		}
		CurrentNode = CurrentNode->Parent;

	}

	for (auto Action  : Results)
	{
		if (priorityAction)
		{

			if (Action->priority > priorityAction->priority)
			{
				priorityAction = Action;
				hasPriority = true;
			}
		}
		else
		{
			priorityAction = Action;
		}
	}
	if (hasPriority)
	{
		Results.Empty();
		Results.Add(priorityAction);
	}

	for (auto Action : Results)
	{
		PlannedActions.Enqueue(Action);
	}
	AllNodes.Empty();
	return true;



}

bool GOAPPlanner::buildGraphRecursive(TArray<GOAPNode*>& AllNodes, GOAPNode* Parent, TArray<GOAPNode*>& GoalNodes, const TSet<GOAPAction*>& AvailiableActions, TMap<FString, bool>& GoalState)
{
	bool hasGoalFound = false;


	for (auto Action : AvailiableActions)
	{
		//Check to see if the preconditions of a state allow it to run
		if (checkConditionsInState(Action->preconditions, Parent->State))
		{

			//create new update state based on current state and action effects
			TMap<FString, bool> CurrentState = pouplateNewState(Parent->State, Action->effects);


			
			GOAPNode* Node = new GOAPNode;
			Node->Parent = Parent;
			Node->RunningCost = Parent->RunningCost + Action->actionCost;
			Node->State = CurrentState;
			Node->Action = Action;

			// add to main list for later deletion
			AllNodes.Add(Node);
			
			if (checkConditionsInState(GoalState, CurrentState))
			{
				//find goal
				GoalNodes.Add(Node);
				hasGoalFound = true;

			}
			else
			{
				//create new actions set without current state
				TSet<GOAPAction*> ActionSubset = createActionSubSet(AvailiableActions, Action);
				hasGoalFound = buildGraphRecursive(AllNodes, Node, GoalNodes, ActionSubset, GoalState);
			}
		}


	}
	return hasGoalFound;
}

TSet<GOAPAction*> GOAPPlanner::createActionSubSet(const TSet<GOAPAction*>& AvailableActions, GOAPAction* RemoveAction)
{
	//create a subset of actions without the provided action
	TSet<GOAPAction*> NewActionSet;
	for (auto Action : AvailableActions)
	{
		if (Action != RemoveAction)
		{
			NewActionSet.Add(Action);
		}
	}
	return NewActionSet;
}

bool GOAPPlanner::checkConditionsInState(TMap<FString, bool>& Conditions, TMap<FString, bool>& States)
{
	//check to see if the first set of conidtions exist in the provided world states
	for (auto Condition : Conditions)
	{
		bool* CurrentStateCondition = States.Find(Condition.Key);
		if (CurrentStateCondition)
		{
			if (Condition.Value != *CurrentStateCondition)
			{
				return false;
			}

		}
		else
		{
			return false;

		}
	}


	return true;
}

TMap<FString, bool> GOAPPlanner::pouplateNewState(const TMap<FString, bool>& CurrentState, TMap<FString, bool>& Changes)
{
	// generate a new state based on current sttae
	TMap<FString, bool> NewState = CurrentState;

	//make changes based on updated changes
	//these are generally an action's effect
	for (auto Pairs : Changes)
	{
		NewState.Add(Pairs.Key, Pairs.Value);
	}
	return NewState;
}