// Fill out your copyright notice in the Description page of Project Settings.


#include "PickupStoneAction.h"
#include "GOAPActor.h"
#include "Stonemason.h"
#include "StoneActor.h"
#include "Kismet/KismetSystemLibrary.h"


PickupStoneAction::PickupStoneAction()
{
	reset();
	// all action except get food has same priority
	priority = 1;
}

PickupStoneAction::~PickupStoneAction()
{
}
bool PickupStoneAction::isActionDone()
{
	if (stoneGathered >= stoneToGather)
	{
		return true;
	}
	return false;
}

bool PickupStoneAction::checkProceduralPrecondition(AGOAPActor* Agent)
{
	if (stoneListArray.Num() == 0)
	{
		TArray<AActor*> mOverlaps;
		TArray<AActor*> mIgnores;

		TArray<TEnumAsByte<EObjectTypeQuery>>objectTypes;
		objectTypes.Add(UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_GameTraceChannel2));

		UKismetSystemLibrary::SphereOverlapActors(Agent->GetWorld(), Agent->GetActorLocation(), 5000.f, objectTypes, NULL, mIgnores, mOverlaps);

		for (auto actor : mOverlaps)
		{
			AStoneActor* stonePointer = Cast<AStoneActor>(actor);
			if (stonePointer)
			{
				stoneListArray.Add(stonePointer);
			}
		}
	}

	AStoneActor* nearestStone = nullptr;
	for (auto stone : stoneListArray)
	{
		if(stone == NULL)
		{
			stoneListArray.Remove(stone);
			continue;
		}
		if (nearestStone)
		{
			if (FVector::Dist(stone->GetActorLocation(), Agent->GetActorLocation()) < FVector::Dist(nearestStone->GetActorLocation(), Agent->GetActorLocation()))
			{
				nearestStone = stone;
			}

		}
		else
		{
			nearestStone = stone;
		}
	}
	if (nearestStone)
	{
		target = nearestStone;
		return true;
	}
	return false;
}


bool PickupStoneAction::performAction(AGOAPActor* Agent)
{
	AStoneActor* stone = Cast<AStoneActor>(target);
	AStonemason* stonemason = Cast<AStonemason>(Agent);

	if (!stone || !stonemason)
	{
		return false;
	}

	
	if(stonemason->health <= stonemason->healthThreshold)
	{
		return false;
	}
	if(stonemason->toolDur <=0)
	{   //destroy tool if dur is run out.
		stonemason->hasTool = false;
		return false;
	}
	if (FDateTime::UtcNow().ToUnixTimestamp() > TargetTime)
	{

		if (stone->getStoneResource() <= 0)
		{
			stoneListArray.Remove(stone);
			checkProceduralPrecondition(Agent);

		}
		else
		{
			if (stone->getStoneResource() <= 1)
			{
				stoneGathered += 1;
				stonemason->NumResource += 1;

				stone->setStoneResource(stone->getStoneResource() - 1);
				TargetTime = FDateTime::UtcNow().ToUnixTimestamp() + Timer;


			}
			else
			{

				stoneGathered += 1;
				stone->setStoneResource(stone->getStoneResource() - 1);
				stonemason->NumResource += 1;
				TargetTime = FDateTime::UtcNow().ToUnixTimestamp() + Timer;
				stone->updateResourceText();


			}
			stonemason->toolDur -= 1;


		}




	}

	return true;
}

bool PickupStoneAction::requiresInRange()
{
	return true;
}

void PickupStoneAction::reset()
{
	setInRange(false);
	target = nullptr;
	stoneGathered = 0;
	TargetTime = FDateTime::UtcNow().ToUnixTimestamp() + Timer;

}
