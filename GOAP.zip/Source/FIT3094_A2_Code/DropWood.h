// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GOAPAction.h"
#include "VillageCentreActor.h"
#include "TreeActor.h"


/**
 * 
 */
class FIT3094_A2_CODE_API DropWood : public GOAPAction
{
public:
	DropWood();
	~DropWood();

	bool isActionDone() override;
	virtual bool checkProceduralPrecondition(AGOAPActor* Agent) override;
	virtual bool performAction(AGOAPActor* Agent) override;
	virtual bool requiresInRange() override;


private:
	void reset() override;
	TArray<AVillageCentreActor* > villageCentres;
	int64 targetTime;

	const int64 timer = 1;
	int resourceOnCarrier;
	
};
