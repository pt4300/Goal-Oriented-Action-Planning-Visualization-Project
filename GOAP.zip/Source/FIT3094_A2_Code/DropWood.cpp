// Fill out your copyright notice in the Description page of Project Settings.


#include "DropWood.h"
#include "WoodCuter.h"
#include "GOAPActor.h"
#include "VillageCentreActor.h"
#include "Kismet/KismetSystemLibrary.h"


DropWood::DropWood()
{
	reset();
	// all action except get food has same priority
	priority = 1;
}

DropWood::~DropWood()
{
}


bool DropWood::isActionDone()
{
	if(resourceOnCarrier <=0)
	{
		return true;
	}
	return false;
}

bool DropWood::checkProceduralPrecondition(AGOAPActor* Agent)
{
	if(villageCentres.Num()==0)
	{
		TArray<AActor*> mOverlaps;
		TArray<AActor*> mIgnores;

		TArray<TEnumAsByte<EObjectTypeQuery>>objectTypes;
		objectTypes.Add(UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_GameTraceChannel1));
		UKismetSystemLibrary::SphereOverlapActors(Agent->GetWorld(), Agent->GetActorLocation(), 5000.f, objectTypes, NULL, mIgnores, mOverlaps);

		for (auto actor : mOverlaps)
		{
			AVillageCentreActor* dropOffPointer = Cast<AVillageCentreActor>(actor);
			if (dropOffPointer)
			{
				villageCentres.Add(dropOffPointer);
			}
		}

	}

	AVillageCentreActor* nearestDropoff = nullptr;

	for (auto dropPoint : villageCentres)
	{
		if (nearestDropoff)
		{
			if (FVector::Dist(dropPoint->GetActorLocation(), Agent->GetActorLocation()) < FVector::Dist(nearestDropoff->GetActorLocation(), Agent->GetActorLocation()))
			{
				nearestDropoff = dropPoint;
			}

		}
		else
		{
			nearestDropoff = dropPoint;
		}
	}
	if (nearestDropoff)
	{
		target = nearestDropoff;
		return true;
	}
	return false;
}

bool DropWood::performAction(AGOAPActor* Agent)
{
	AVillageCentreActor* DropLoad = Cast<AVillageCentreActor>(target);
	AWoodCuter* Gather = Cast<AWoodCuter>(Agent);

	if (!DropLoad || !Gather)
	{
		return false;
	}

	if (FDateTime::UtcNow().ToUnixTimestamp() > targetTime)
	{
		UE_LOG(LogTemp, Warning, TEXT("resource prepare to drop: %i"),Gather->NumResource);

		DropLoad->setWoodResource(Gather->NumResource);
		Gather->NumResource = 0;
		resourceOnCarrier = Gather->NumResource;

		targetTime = FDateTime::UtcNow().ToUnixTimestamp() + timer;
	}
	return true;
}

bool DropWood::requiresInRange()
{
	return true;
}


void DropWood::reset()
{
	setInRange(false);
	target = nullptr;
	resourceOnCarrier = 99999;
	targetTime = FDateTime::UtcNow().ToUnixTimestamp() + timer;

}

