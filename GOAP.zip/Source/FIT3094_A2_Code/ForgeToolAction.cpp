// Fill out your copyright notice in the Description page of Project Settings.


#include "ForgeToolAction.h"

#include "Kismet/KismetSystemLibrary.h"

ForgeToolAction::ForgeToolAction()
{
	reset();
	// all action except get food has same priority
	priority = 1;
}

ForgeToolAction::~ForgeToolAction()
{
}
bool ForgeToolAction::isActionDone()
{
	if (toolGathered >= treeToGather)
	{
		return true;
	}
	return false;
}

bool ForgeToolAction::checkProceduralPrecondition(AGOAPActor* Agent)
{
	if (forgeListArray.Num() == 0)
	{
		TArray<AActor*> mOverlaps;
		TArray<AActor*> mIgnores;

		TArray<TEnumAsByte<EObjectTypeQuery>>objectTypes;
		objectTypes.Add(UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_GameTraceChannel1));

		UKismetSystemLibrary::SphereOverlapActors(Agent->GetWorld(), Agent->GetActorLocation(), 5000.f, objectTypes, NULL, mIgnores, mOverlaps);

		for (auto actor : mOverlaps)
		{
			AForgeActor* forgePointer = Cast<AForgeActor>(actor);
			if (forgePointer)
			{
				forgeListArray.Add(forgePointer);
			}
		}
	}

	AForgeActor* nearestForge = nullptr;
	for (auto forge : forgeListArray)
	{

		if (nearestForge)
		{
			if (FVector::Dist(forge->GetActorLocation(), Agent->GetActorLocation()) < FVector::Dist(nearestForge->GetActorLocation(), Agent->GetActorLocation()))
			{
				nearestForge = forge;
			}

		}
		else
		{
			nearestForge = forge;
		}
	}
	if (nearestForge)
	{
		target = nearestForge;
		return true;
	}
	return false;
}


bool ForgeToolAction::performAction(AGOAPActor* Agent)
{
	//do not disrupt if health below threshold since it only takes 1 second to forge
	AForgeActor* forge = Cast<AForgeActor>(target);
	AMiner* miner = Cast<AMiner>(Agent);

	if (!forge || !miner)
	{
		return false;
	}
	if (FDateTime::UtcNow().ToUnixTimestamp() > TargetTime)
	{

		if(forge->getMetal()>= 7 )
		{
			forge->setMetal(-7);
			miner->forgedTools += 1;
			isToolCrafted = true;
			TargetTime = FDateTime::UtcNow().ToUnixTimestamp() + Timer;
		}
		else
		{
			// return false if there is not enough metal for tool crafting
			return false;
		}

	}
	return true;
}

bool ForgeToolAction::requiresInRange()
{
	return true;
}

void ForgeToolAction::reset()
{
	setInRange(false);
	isToolCrafted = false;
	target = nullptr;
	toolGathered = 0;
	TargetTime = FDateTime::UtcNow().ToUnixTimestamp() + Timer;

}
