// Fill out your copyright notice in the Description page of Project Settings.


#include "DropOreAction.h"
#include "Miner.h"
#include "Kismet/KismetSystemLibrary.h"
#include "VillageCentreActor.h"

DropOreAction::DropOreAction()
{
	reset();
	// all action except get food has same priority
	priority = 1;
}

DropOreAction::~DropOreAction()
{
}

bool DropOreAction::isActionDone()
{
	if (resourceOnCarrier <= 0)
	{
		return true;
	}
	return false;
}

bool DropOreAction::checkProceduralPrecondition(AGOAPActor* Agent)
{
	if (forge.Num() == 0)
	{
		TArray<AActor*> mOverlaps;
		TArray<AActor*> mIgnores;

		TArray<TEnumAsByte<EObjectTypeQuery>>objectTypes;
		objectTypes.Add(UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_GameTraceChannel1));
		UKismetSystemLibrary::SphereOverlapActors(Agent->GetWorld(), Agent->GetActorLocation(), 5000.f, objectTypes, NULL, mIgnores, mOverlaps);

		for (auto actor : mOverlaps)
		{
			AForgeActor* dropOffPointer = Cast<AForgeActor>(actor);
			if (dropOffPointer)
			{
				forge.Add(dropOffPointer);
			}
		}

	}

	AForgeActor* nearestDropoff = nullptr;

	for (auto dropPoint : forge)
	{
		if (nearestDropoff)
		{
			if (FVector::Dist(dropPoint->GetActorLocation(), Agent->GetActorLocation()) < FVector::Dist(nearestDropoff->GetActorLocation(), Agent->GetActorLocation()))
			{
				nearestDropoff = dropPoint;
			}

		}
		else
		{
			nearestDropoff = dropPoint;
		}
	}
	if (nearestDropoff)
	{
		target = nearestDropoff;
		return true;
	}
	return false;
}

bool DropOreAction::performAction(AGOAPActor* Agent)
{
	//do not disrupt if health below threshold since it only takes 1 second to forge

	AForgeActor* DropLoad = Cast<AForgeActor>(target);
	AMiner* Gather = Cast<AMiner>(Agent);

	if (!DropLoad || !Gather)
	{
		return false;
	}

	if (FDateTime::UtcNow().ToUnixTimestamp() > targetTime)
	{
		DropLoad->setMetal(10);
		Gather->NumResource -= 10;
		resourceOnCarrier = Gather->NumResource;

		if(DropLoad->getMetal()>=7)
		{
			int maxToolCrafte = DropLoad->getMetal() / 7;
			Gather->forgedTools += maxToolCrafte;
			DropLoad->setMetal(-(maxToolCrafte*7));

		}
		targetTime = FDateTime::UtcNow().ToUnixTimestamp() + timer;
	}
	return true;
}

bool DropOreAction::requiresInRange()
{
	return true;
}


void DropOreAction::reset()
{
	setInRange(false);
	target = nullptr;
	resourceOnCarrier = 99999;
	targetTime = FDateTime::UtcNow().ToUnixTimestamp() + timer;

}
