// Fill out your copyright notice in the Description page of Project Settings.


#include "PickupWood.h"
#include "GOAPActor.h"
#include "WoodCuter.h"
#include "TreeActor.h"
#include "Kismet/KismetSystemLibrary.h"

PickupWood::PickupWood()
{
	reset();
	// all action except get food has same priority
	priority = 1;
}

PickupWood::~PickupWood()
{
}

bool PickupWood::isActionDone()
{
	if(treeGathered >= treeToGather)
	{
		return true;
	}
	return false;
}

bool PickupWood::checkProceduralPrecondition(AGOAPActor* Agent)
{
	if(treeListArray.Num() == 0)
	{
		TArray<AActor*> mOverlaps;
		TArray<AActor*> mIgnores;

		TArray<TEnumAsByte<EObjectTypeQuery>>objectTypes;
		objectTypes.Add(UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_GameTraceChannel1));

		UKismetSystemLibrary::SphereOverlapActors(Agent->GetWorld(), Agent->GetActorLocation(), 5000.f, objectTypes, NULL, mIgnores, mOverlaps);

		for (auto actor : mOverlaps)
		{
			ATreeActor* treePointer = Cast<ATreeActor>(actor);
			if (treePointer)
			{
				treeListArray.Add(treePointer);
			}
		}
	}

	ATreeActor* nearestTree = nullptr;
	for (auto tree : treeListArray)
	{
		if(tree == NULL)
		{
			treeListArray.Remove(tree);
			continue;
		}
		if (nearestTree)
		{
			if (FVector::Dist(tree->GetActorLocation(), Agent->GetActorLocation()) < FVector::Dist(nearestTree->GetActorLocation(), Agent->GetActorLocation()))
			{
				nearestTree = tree;
			}

		}
		else
		{
			nearestTree = tree;
		}
	}
	if (nearestTree)
	{
		target = nearestTree;
		return true;
	}
	return false;
}


bool PickupWood::performAction(AGOAPActor* Agent)
{
	ATreeActor* tree = Cast<ATreeActor>(target);
	AWoodCuter* woodCuter = Cast<AWoodCuter>(Agent);

	if(!tree || !woodCuter)
	{
		return false;
	}
	if(woodCuter->health <= woodCuter->healthThreshold)
	{
		return false;
	}
	if (woodCuter->toolDur <= 0)
	{
		//destroy tool if dur is run out.
		woodCuter->hasTool = false;

		return false;
	}
	if (FDateTime::UtcNow().ToUnixTimestamp() > TargetTime)
	{
		
		if(tree->getWoodResource()<=0)
		{
			treeListArray.Remove(tree);
			checkProceduralPrecondition(Agent);
			return false;
			
		}else
		{
			if(tree->getWoodResource() <= 1)
			{
				woodCuter->NumResource += 1;
				treeGathered = woodCuter->NumResource;
				
				tree->setWoodResource(tree->getWoodResource() - 1);
				tree->updateResourceText();
				TargetTime = FDateTime::UtcNow().ToUnixTimestamp() + Timer;
				
				return false;
				
				
			}else
			{
					woodCuter->NumResource += 1;
					treeGathered = woodCuter->NumResource;
					tree->setWoodResource(tree->getWoodResource() - 1);

					tree->updateResourceText();
					TargetTime = FDateTime::UtcNow().ToUnixTimestamp() + Timer;
				

			}
			woodCuter->toolDur -= 1;
			UE_LOG(LogTemp, Warning, TEXT("current tool dur: %i"), woodCuter->toolDur);


		}


	}


	return true;
}

bool PickupWood::requiresInRange()
{
	return true;
}

void PickupWood::reset()
{
	setInRange(false);
	target = nullptr;
	treeGathered = 0;
	TargetTime = FDateTime::UtcNow().ToUnixTimestamp() + Timer;

}


 
