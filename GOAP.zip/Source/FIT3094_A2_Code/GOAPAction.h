// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"


//Foward declaration of GOAP Actor to avoid dependcy loop
class AGOAPActor;

/**
 * 
 */

class FIT3094_A2_CODE_API GOAPAction
{
public:
	GOAPAction();
	~GOAPAction();
	//List of conditions required for this action to be valid
	TMap<FString, bool> preconditions;
	//List of effects this action has on the world
	TMap<FString, bool> effects;


	//Cost of action, can be changed at run time
	float actionCost;
	// the pripority for each action, avoid keep infinite loop due to same action be schedule at same time
	int priority;
	//generic target, sub class can be cast on it
	AActor* target;

	// reset action to base state
	void doReset();

	//Adding and remove preconditions
	void addPreconditions(FString Name, bool state);
	void removePreconditions(FString name);

	void addEffects(FString Name, bool state);
	void removeEffects(FString name);

	//set/check wehther or not the action is within range
	bool isInRange() const { return inRange; }
	void setInRange(const bool range) { inRange = range; }


	//Check whether or not an action has finished executing
	virtual bool isActionDone() = 0;
	
	// check procedural preconditions at runtime, provided an agent
	virtual bool checkProceduralPrecondition(AGOAPActor*Agent) = 0;

	virtual bool performAction(AGOAPActor* Agent) = 0;

	//Whether ot not the action actually requires something in range
	virtual bool requiresInRange() = 0;


private:
	bool inRange;

	virtual void reset()= 0;
	



};
