// Fill out your copyright notice in the Description page of Project Settings.


#include "PickupOreAction.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Miner.h"

PickupOreAction::PickupOreAction()
{
	reset();
	// all action except get food has same priority
	priority = 1;
}

PickupOreAction::~PickupOreAction()
{
}
bool PickupOreAction::isActionDone()
{
	if (oreGathered >= oreToGather)
	{
		return true;
	}
	return false;
}

bool PickupOreAction::checkProceduralPrecondition(AGOAPActor* Agent)
{
	if (oreListArray.Num() == 0)
	{
		TArray<AActor*> mOverlaps;
		TArray<AActor*> mIgnores;

		TArray<TEnumAsByte<EObjectTypeQuery>>objectTypes;
		objectTypes.Add(UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_GameTraceChannel1));

		UKismetSystemLibrary::SphereOverlapActors(Agent->GetWorld(), Agent->GetActorLocation(), 5000.f, objectTypes, NULL, mIgnores, mOverlaps);

		for (auto actor : mOverlaps)
		{
			AMineActor* treePointer = Cast<AMineActor>(actor);
			if (treePointer)
			{
				oreListArray.Add(treePointer);
			}
		}
	}

	AMineActor* nearestOre = nullptr;
	for (auto ore : oreListArray)
	{
		if (ore == NULL)
		{
			oreListArray.Remove(ore);
			continue;
		}
		if (nearestOre)
		{
			if (FVector::Dist(ore->GetActorLocation(), Agent->GetActorLocation()) < FVector::Dist(nearestOre->GetActorLocation(), Agent->GetActorLocation()))
			{
				nearestOre = ore;
			}

		}
		else
		{
			nearestOre = ore;
		}
	}
	if (nearestOre)
	{
		target = nearestOre;
		return true;
	}
	return false;
}


bool PickupOreAction::performAction(AGOAPActor* Agent)
{
	
	AMineActor* ore = Cast<AMineActor>(target);
	AMiner* miner = Cast<AMiner>(Agent);

	if (!ore || !miner)
	{
		return false;
	}
	if(miner->health <= miner->healthThreshold)
	{
		return false;
	}
	if (FDateTime::UtcNow().ToUnixTimestamp() > TargetTime)
	{

		if (ore->getMetalResource() <= 0)
		{
			oreListArray.Remove(ore);
			checkProceduralPrecondition(Agent);

		}
		else
		{
			if (ore->getMetalResource() <= oreGatheredEachTime)
			{
				oreGathered += ore->getMetalResource();
				ore->setMetalResource(ore->getMetalResource() - ore->getMetalResource());
				miner->NumResource += ore->getMetalResource();

				TargetTime = FDateTime::UtcNow().ToUnixTimestamp() + Timer;


			}
			else
			{

				oreGathered += oreGatheredEachTime;
				ore->setMetalResource(ore->getMetalResource() - oreGatheredEachTime);
				miner->NumResource += oreGatheredEachTime;

				TargetTime = FDateTime::UtcNow().ToUnixTimestamp() + Timer;


			}

		}


	}
	return true;
}

bool PickupOreAction::requiresInRange()
{
	return true;
}

void PickupOreAction::reset()
{
	setInRange(false);
	target = nullptr;
	oreGathered = 0;
	TargetTime = FDateTime::UtcNow().ToUnixTimestamp() + Timer;

}

