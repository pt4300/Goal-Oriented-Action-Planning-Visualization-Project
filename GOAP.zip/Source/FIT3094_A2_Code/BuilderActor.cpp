// Fill out your copyright notice in the Description page of Project Settings.


#include "BuilderActor.h"
#include "GOAPPlanner.h"
#include "PickupBuilderResource.h"
#include "DropToBuildingSite.h"
#include "EatFoodAction.h"
#include "VillageCentreActor.h"


ABuilderActor::ABuilderActor()
{
	
}

void ABuilderActor::BeginPlay()
{
	Super::BeginPlay();
	health = 400;
	healthThreshold = 15;
	PickupBuilderResource* pickUpResource = new PickupBuilderResource();
	pickUpResource->addPreconditions("HasResource", false);
	pickUpResource->addEffects("HasResource", true);
	DropToBuildingSite* dropResource = new DropToBuildingSite();
	dropResource->addPreconditions("HasResource", true);
	dropResource->addEffects("HasResource", false);
	dropResource->addEffects("collectResource", true);
	EatFoodAction* eatFoodAct = new EatFoodAction();
	eatFoodAct->addPreconditions("lowHealth", true);
	eatFoodAct->addEffects("lowHealth", false);
	availableActions.Add(pickUpResource);
	availableActions.Add(dropResource);
	availableActions.Add(eatFoodAct);
}


void ABuilderActor::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (actionStateMachine->GetCurrentState() == State_Action || actionStateMachine->GetCurrentState() == State_Move)
	{
		if (FDateTime::UtcNow().ToUnixTimestamp() > TargetTime)
		{
			decreaseHealth();
			UE_LOG(LogTemp, Warning, TEXT("current builder health %i"), health);
			TargetTime = FDateTime::UtcNow().ToUnixTimestamp() + Timer;

		}
	}




}


TMap<FString, bool> ABuilderActor::getWorldStates()
{
	TMap<FString, bool> worldState = Super::getWorldStates();

	worldState.Add("lowHealth", health <= healthThreshold);
	
	worldState.Add("HasResource", stoneNum > 0 && woodNum >0 );


	return worldState;
}

TMap<FString, bool> ABuilderActor::createGoalState()
{
	TMap<FString, bool> GoalState;

	GoalState.Add("lowHealth", false);


	GoalState.Add("collectResource", true);



	return GoalState;
}

