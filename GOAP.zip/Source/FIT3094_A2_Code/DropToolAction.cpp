// Fill out your copyright notice in the Description page of Project Settings.


#include "DropToolAction.h"

#include "Kismet/KismetSystemLibrary.h"

DropToolAction::DropToolAction()
{
	reset();
	// all action except get food has same priority
	priority = 1;
}

DropToolAction::~DropToolAction()
{
}


bool DropToolAction::isActionDone()
{
	if (resourceOnCarrier == 0)
	{
		return true;
	}
	return false;
}

bool DropToolAction::checkProceduralPrecondition(AGOAPActor* Agent)
{
	if (villageCentres.Num() == 0)
	{
		TArray<AActor*> mOverlaps;
		TArray<AActor*> mIgnores;

		TArray<TEnumAsByte<EObjectTypeQuery>>objectTypes;
		objectTypes.Add(UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_GameTraceChannel1));
		UKismetSystemLibrary::SphereOverlapActors(Agent->GetWorld(), Agent->GetActorLocation(), 5000.f, objectTypes, NULL, mIgnores, mOverlaps);

		for (auto actor : mOverlaps)
		{
			AVillageCentreActor* dropOffPointer = Cast<AVillageCentreActor>(actor);
			if (dropOffPointer)
			{
				villageCentres.Add(dropOffPointer);
			}
		}

	}

	AVillageCentreActor* nearestDropoff = nullptr;

	for (auto dropPoint : villageCentres)
	{
		if (nearestDropoff)
		{
			if (FVector::Dist(dropPoint->GetActorLocation(), Agent->GetActorLocation()) < FVector::Dist(nearestDropoff->GetActorLocation(), Agent->GetActorLocation()))
			{
				nearestDropoff = dropPoint;
			}

		}
		else
		{
			nearestDropoff = dropPoint;
		}
	}
	if (nearestDropoff)
	{
		target = nearestDropoff;
		return true;
	}
	return false;
}

bool DropToolAction::performAction(AGOAPActor* Agent)
{
	AVillageCentreActor* DropLoad = Cast<AVillageCentreActor>(target);
	AMiner* Gather = Cast<AMiner>(Agent);

	if (!DropLoad || !Gather)
	{
		return false;
	}

	if (FDateTime::UtcNow().ToUnixTimestamp() > targetTime)
	{
		
		DropLoad->setTools(Gather->forgedTools);
		Gather->forgedTools = 0;
		resourceOnCarrier = Gather->forgedTools;

		targetTime = FDateTime::UtcNow().ToUnixTimestamp() + timer;
	}
	return true;
}

bool DropToolAction::requiresInRange()
{
	return true;
}


void DropToolAction::reset()
{
	setInRange(false);
	target = nullptr;
	resourceOnCarrier = 99999;
	targetTime = FDateTime::UtcNow().ToUnixTimestamp() + timer;

}