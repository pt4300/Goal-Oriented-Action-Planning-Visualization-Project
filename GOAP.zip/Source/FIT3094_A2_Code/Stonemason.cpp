// Fill out your copyright notice in the Description page of Project Settings.


#include "Stonemason.h"
#include "GOAPPlanner.h"
#include "PickupStoneAction.h"
#include "DropStone.h"
#include "EatFoodAction.h"
#include "PickupToolAction.h"


AStonemason::AStonemason()
{
	
}


void AStonemason::BeginPlay()
{
	Super::BeginPlay();
	health = 100;
	healthThreshold = 40;
	PickupToolAction* pickTool = new PickupToolAction();
	pickTool->addPreconditions("HasTool", false);
	pickTool->addEffects("HasTool", true);
	PickupStoneAction* pickStoneAction = new PickupStoneAction();
	pickStoneAction->addPreconditions("HasTool", true);
	pickStoneAction->addPreconditions("HasStone", false);
	pickStoneAction->addEffects("HasStone", true);
	DropStone* dropStoneAction = new DropStone();
	dropStoneAction->addPreconditions("HasStone", true);
	dropStoneAction->addEffects("HasStone", false);
	dropStoneAction->addEffects("collectStone", true);
	EatFoodAction* eatFoodAct = new EatFoodAction();
	eatFoodAct->addPreconditions("lowHealth", true);
	eatFoodAct->addEffects("lowHealth", false);
	availableActions.Add(pickStoneAction);
	availableActions.Add(pickTool);
	availableActions.Add(dropStoneAction);
	availableActions.Add(eatFoodAct);

}

void AStonemason::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);
	if (actionStateMachine->GetCurrentState() == State_Action || actionStateMachine->GetCurrentState() == State_Move)
	{
		if (FDateTime::UtcNow().ToUnixTimestamp() > TargetTime)
		{
			decreaseHealth();
			UE_LOG(LogTemp, Warning, TEXT("current stone health %i"), health);
			TargetTime = FDateTime::UtcNow().ToUnixTimestamp() + Timer;

		}
	}
}

TMap<FString, bool> AStonemason::getWorldStates()
{
	TMap<FString, bool> worldState = Super::getWorldStates();
	worldState.Add("lowHealth", health <= healthThreshold);
	worldState.Add("HasStone", NumResource >= 20);
	worldState.Add("HasTool", hasTool);
	return worldState;
}


TMap<FString, bool> AStonemason::createGoalState()
{
	TMap<FString, bool> GoalState;
	GoalState.Add("lowHealth", false);
	GoalState.Add("collectStone", true);

	return GoalState;
}
