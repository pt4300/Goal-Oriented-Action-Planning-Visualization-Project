// Fill out your copyright notice in the Description page of Project Settings.


#include "DropToBuildingSite.h"
#include "BuilderActor.h"
#include "GOAPActor.h"
#include "BuildingActor.h"
#include "Kismet/KismetSystemLibrary.h"

DropToBuildingSite::DropToBuildingSite()
{
	reset();
	// all action except get food has same priority
	priority = 1;
}

DropToBuildingSite::~DropToBuildingSite()
{
}
bool DropToBuildingSite::isActionDone()
{
	if (woodOnCarrier <= 0 && stoneOnCarrier <= 0)
	{
		return true;
	}
	return false;
}

bool DropToBuildingSite::checkProceduralPrecondition(AGOAPActor* Agent)
{
	if (villageCentres.Num() == 0)
	{
		TArray<AActor*> mOverlaps;
		TArray<AActor*> mIgnores;

		TArray<TEnumAsByte<EObjectTypeQuery>>objectTypes;
		objectTypes.Add(UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_GameTraceChannel1));
		UKismetSystemLibrary::SphereOverlapActors(Agent->GetWorld(), Agent->GetActorLocation(), 5000.f, objectTypes, NULL, mIgnores, mOverlaps);

		for (auto actor : mOverlaps)
		{
			ABuildingActor* dropOffPointer = Cast<ABuildingActor>(actor);
			if (dropOffPointer)
			{
				villageCentres.Add(dropOffPointer);
			}
		}

	}

	ABuildingActor* nearestDropoff = nullptr;

	for (auto dropPoint : villageCentres)
	{
		if (nearestDropoff)
		{
			if (FVector::Dist(dropPoint->GetActorLocation(), Agent->GetActorLocation()) < FVector::Dist(nearestDropoff->GetActorLocation(), Agent->GetActorLocation()))
			{
				nearestDropoff = dropPoint;
			}

		}
		else
		{
			nearestDropoff = dropPoint;
		}
	}
	if (nearestDropoff)
	{
		target = nearestDropoff;
		return true;
	}
	return false;
}

bool DropToBuildingSite::performAction(AGOAPActor* Agent)
{
	ABuildingActor* DropLoad = Cast<ABuildingActor>(target);
	ABuilderActor* Gather = Cast<ABuilderActor>(Agent);

	if (!DropLoad || !Gather)
	{
		return false;
	}

	if (FDateTime::UtcNow().ToUnixTimestamp() > targetTime)
	{
		if(Gather->woodNum > 0 )
		{
			DropLoad->setWoodResource(Gather->woodNum);
			Gather->woodNum = 0;
			woodOnCarrier = Gather->woodNum;
		}
		else if(Gather->stoneNum> 0)
		{
			DropLoad->setStoneResource(Gather->stoneNum);
			Gather->stoneNum = 0 ;
			stoneOnCarrier = Gather->stoneNum;
		}

		targetTime = FDateTime::UtcNow().ToUnixTimestamp() + timer;
	}
	return true;
}

bool DropToBuildingSite::requiresInRange()
{
	return true;
}


void DropToBuildingSite::reset()
{
	setInRange(false);
	target = nullptr;
	woodOnCarrier = 99999;
	stoneOnCarrier = 99999;
	targetTime = FDateTime::UtcNow().ToUnixTimestamp() + timer;

}
