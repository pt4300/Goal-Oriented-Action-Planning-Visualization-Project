// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GOAPAction.h"
#include "StoneActor.h"

/**
 * 
 */
class FIT3094_A2_CODE_API PickupStoneAction : public GOAPAction
{
public:
	PickupStoneAction();
	~PickupStoneAction();
	bool isActionDone() override;
	virtual bool checkProceduralPrecondition(AGOAPActor* Agent) override;
	virtual bool performAction(AGOAPActor* Agent) override;
	virtual bool requiresInRange() override;

private:
	virtual  void reset() override;




	TArray<AStoneActor*> stoneListArray;

	int32 stoneGathered;
	int64 TargetTime;

	const int64 Timer = 1;

	const int32 stoneToGather = 20;

};
