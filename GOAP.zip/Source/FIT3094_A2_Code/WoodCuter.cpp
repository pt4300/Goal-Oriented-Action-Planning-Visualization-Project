// Fill out your copyright notice in the Description page of Project Settings.


#include "WoodCuter.h"
#include "GOAPPlanner.h"
#include "PickupWood.h"
#include "DropWood.h"
#include "EatFoodAction.h"
#include "PickupToolAction.h"


AWoodCuter::AWoodCuter()
{
	
}

void AWoodCuter::BeginPlay()
{
	Super::BeginPlay();
	health = 50;
	healthThreshold = 15;
	PickupToolAction* pickTool = new PickupToolAction();
	pickTool->addPreconditions("HasTool", false);
	pickTool->addEffects("HasTool", true);
	PickupWood* pickAction = new PickupWood();
	pickAction->addPreconditions("HasTool", true);
	pickAction->addPreconditions("HasWood", false);
	pickAction->addEffects("HasWood", true);
	DropWood* dropWoodAction = new DropWood();
	dropWoodAction->addPreconditions("HasWood", true);
	dropWoodAction->addEffects("HasWood", false);
	dropWoodAction->addEffects("collectWood", true);
	EatFoodAction* eatFoodAct = new EatFoodAction();
	eatFoodAct->addPreconditions("lowHealth", true);
	eatFoodAct->addEffects("lowHealth", false);
	availableActions.Add(pickAction);
	availableActions.Add(dropWoodAction);
	availableActions.Add(pickTool);
	availableActions.Add(eatFoodAct);

}


void AWoodCuter::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if(actionStateMachine->GetCurrentState() ==State_Action || actionStateMachine->GetCurrentState() == State_Move)
	{
		if (FDateTime::UtcNow().ToUnixTimestamp() > TargetTime)
		{
			decreaseHealth();
			UE_LOG(LogTemp, Warning, TEXT("current wood health %i"),health);
			TargetTime = FDateTime::UtcNow().ToUnixTimestamp() + Timer;

		}
	}

	



}


TMap<FString, bool> AWoodCuter::getWorldStates()
{
	TMap<FString, bool> worldState = Super::getWorldStates();

		worldState.Add("lowHealth", health <= healthThreshold);

		worldState.Add("HasWood", NumResource >= 4);

		worldState.Add("HasTool", hasTool);

		//worldState.Add("collectWood", NumResource <= 4);



	return worldState;
}

TMap<FString, bool> AWoodCuter::createGoalState()
{
	TMap<FString, bool> GoalState;


	if(health <= healthThreshold)
	{
		GoalState.Add("lowHealth", false);
	}
	else
	{
		GoalState.Add("collectWood", true);

	}



	
	
		




	return GoalState;
}




