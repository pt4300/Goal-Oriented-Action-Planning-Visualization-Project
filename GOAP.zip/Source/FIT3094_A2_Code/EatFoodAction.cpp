// Fill out your copyright notice in the Description page of Project Settings.


#include "EatFoodAction.h"
#include "GOAPActor.h"
#include "WoodCuter.h"
#include "BuilderActor.h"
#include  "Stonemason.h"
#include "FoodActor.h"

#include "Kismet/KismetSystemLibrary.h"

EatFoodAction::EatFoodAction()
{
	reset();
	// EAT FOOD HAS HIGHER PRIORITY
	priority = 3;
}

EatFoodAction::~EatFoodAction()
{
}
bool EatFoodAction::isActionDone()
{
	if (isFoodEaten)
	{
		return true;
	}
	return false;
}

bool EatFoodAction::checkProceduralPrecondition(AGOAPActor* Agent)
{
	// recast sphere overlap when food array drop below 5
	if (foodArray.Num() <= 5)
	{
		TArray<AActor*> mOverlaps;
		TArray<AActor*> mIgnores;

		TArray<TEnumAsByte<EObjectTypeQuery>>objectTypes;
		objectTypes.Add(UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_GameTraceChannel1));

		UKismetSystemLibrary::SphereOverlapActors(Agent->GetWorld(), Agent->GetActorLocation(), 5000.f, objectTypes, NULL, mIgnores, mOverlaps);

		for (auto actor : mOverlaps)
		{
			AFoodActor* foodPointer = Cast<AFoodActor>(actor);
			if (foodPointer && foodPointer->IsValidLowLevel())
			{
				foodArray.Add(foodPointer);
			}
		}
	}
	AFoodActor* nearestFood = nullptr;
	for (auto food : foodArray)
	{
		//check whether food is still valid
		if(!food || !food->IsValidLowLevel())
		{
			foodArray.Remove(food);
			continue;
		}
		if (nearestFood)
		{
			if (FVector::Dist(food->GetActorLocation(), Agent->GetActorLocation()) < FVector::Dist(nearestFood->GetActorLocation(), Agent->GetActorLocation()))
			{
				nearestFood = food;
			}

		}
		else
		{
			nearestFood = food;
		}
	}
	if (nearestFood)
	{
		foodArray.Remove(nearestFood);
		target = nearestFood;
		return true;
	}
	return false;
}


bool EatFoodAction::performAction(AGOAPActor* Agent)
{
	if (!target || !target->IsValidLowLevel())
	{
		// if target is eaten by other agent, refetch nearest food
		checkProceduralPrecondition(Agent);
	}
	AFoodActor* food = Cast<AFoodActor>(target);

	

	
	if (!food)
	{
		return false;
	}


	if (FDateTime::UtcNow().ToUnixTimestamp() > TargetTime)
	{

			isFoodEaten = true;
			TargetTime = FDateTime::UtcNow().ToUnixTimestamp() + Timer;



	}
	return true;
}

bool EatFoodAction::requiresInRange()
{
	return true;
}

void EatFoodAction::reset()
{
	setInRange(false);
	target = nullptr;
	isFoodEaten = false;
	TargetTime = FDateTime::UtcNow().ToUnixTimestamp() + Timer;

}
