// Fill out your copyright notice in the Description page of Project Settings.


#include "Miner.h"
#include "PickupOreAction.h"
#include "DropOreAction.h"
#include "EatFoodAction.h"
#include "ForgeToolAction.h"
#include "DropToolAction.h"

AMiner::AMiner()
{

}

void AMiner::BeginPlay()
{
	Super::BeginPlay();
	health = 10000;
	healthThreshold = 50;
	PickupOreAction* pickOreAction = new PickupOreAction();
	pickOreAction->addPreconditions("HasOre", false);
	pickOreAction->addEffects("HasOre", true);
	DropOreAction* dropOreAction = new DropOreAction();
	dropOreAction->addPreconditions("HasOre", true);
	dropOreAction->addEffects("HasOre", false);
	dropOreAction->addEffects("HasTool", true);
	EatFoodAction* eatFoodAct = new EatFoodAction();
	eatFoodAct->addPreconditions("lowHealth", true);
	eatFoodAct->addEffects("lowHealth", false);
	//ForgeToolAction* forgeToolsAct = new ForgeToolAction();
	//forgeToolsAct->addPreconditions("HasTool", false);
	//forgeToolsAct->addEffects("HasTool", true);
	DropToolAction* dropTool = new DropToolAction();
	dropTool->addPreconditions("HasTool", true);
	dropTool->addEffects("HasTool", false);
	dropTool->addEffects("collectTools", true);
	availableActions.Add(dropTool);
	availableActions.Add(pickOreAction);
	availableActions.Add(dropOreAction);
	availableActions.Add(eatFoodAct);
	//availableActions.Add(forgeToolsAct);

}


void AMiner::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (actionStateMachine->GetCurrentState() == State_Action || actionStateMachine->GetCurrentState() == State_Move)
	{
		if (FDateTime::UtcNow().ToUnixTimestamp() > TargetTime)
		{
			decreaseHealth();
			UE_LOG(LogTemp, Warning, TEXT("current miner health %i"), health);
			TargetTime = FDateTime::UtcNow().ToUnixTimestamp() + Timer;

		}
	}



}


TMap<FString, bool> AMiner::getWorldStates()
{
	TMap<FString, bool> worldState = Super::getWorldStates();

	worldState.Add("lowHealth", health <= healthThreshold);

	worldState.Add("HasOre", NumResource > 0);

	worldState.Add("HasTool", forgedTools > 0);

	


	return worldState;
}

TMap<FString, bool> AMiner::createGoalState()
{
	TMap<FString, bool> GoalState;


	GoalState.Add("lowHealth", false);

	//GoalState.Add("collectOre", true);

	GoalState.Add("collectTools", true);






	return GoalState;
}
