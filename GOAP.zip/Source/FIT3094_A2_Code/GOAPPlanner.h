// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Containers/Queue.h"

/**
 * 
 */
//Forward declaration 
class AGOAPActor;
class GOAPAction;

struct GOAPNode
{
	GOAPNode* Parent;

	float RunningCost;

	// current state of world when reaching this point, this will be the world state with all previous effects applied
	TMap<FString, bool>State;
	//assoicated action
	GOAPAction* Action;
};

class FIT3094_A2_CODE_API GOAPPlanner
{
public:
	GOAPPlanner();
	~GOAPPlanner();

	static bool plan(AGOAPActor* Agent, const TSet<GOAPAction*>& availableActions, TQueue<GOAPAction*>& PlannedActions, TMap<FString, bool>WorldState, TMap<FString, bool>GoalState);

protected:
	static bool buildGraphRecursive(TArray<GOAPNode*>&AllNodes, GOAPNode* Parent, TArray<GOAPNode*>&GoalNodes, const TSet<GOAPAction*>& AvailiableActions, TMap<FString, bool>& GoalState);
	
	static TSet<GOAPAction*> createActionSubSet(const TSet<GOAPAction*>& AvailableActions, GOAPAction* RemoveAction);

	static bool checkConditionsInState(TMap<FString, bool>&Conditions, TMap<FString, bool>& States);

	// combine current state with the changes of an actions(effects)
	static TMap<FString, bool> pouplateNewState(const TMap<FString, bool>& CurrentState, TMap<FString, bool>& Changes);
};
