// Fill out your copyright notice in the Description page of Project Settings.


#include "GOAPAction.h"

GOAPAction::GOAPAction()
{
}

GOAPAction::~GOAPAction()
{
}


void GOAPAction::doReset()
{
	inRange = false;
	target = nullptr;

	
	reset();
}


void GOAPAction::addPreconditions(FString Name, bool State)
{
	preconditions.Add(Name, State);
}

void GOAPAction::addEffects(FString Name, bool State)
{
	effects.Add(Name, State);
}

void GOAPAction::removePreconditions(FString Name)
{
	preconditions.Remove(Name);
}

void GOAPAction::removeEffects(FString Name)
{
	effects.Remove(Name);
}

