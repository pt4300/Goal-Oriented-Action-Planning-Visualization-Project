// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GOAPActor.h"
#include "Components/StaticMeshComponent.h"

#include "WoodCuter.generated.h"

/**
 * 
 */
UCLASS()
class FIT3094_A2_CODE_API AWoodCuter : public AGOAPActor
{
	GENERATED_BODY()


protected:
	virtual void BeginPlay() override;
public:
	AWoodCuter();
	

	virtual  void Tick(float DeltaSeconds) override;
	TMap<FString, bool>getWorldStates() override;
	TMap<FString, bool> createGoalState() override;
	int NumResource;
	bool hasTool = false;
	int toolDur = 0;
	int64 Timer = 1;
	int64 TargetTime = TargetTime = FDateTime::UtcNow().ToUnixTimestamp() + Timer;;

};
