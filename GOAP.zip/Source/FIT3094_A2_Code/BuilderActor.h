// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GOAPActor.h"
#include "BuilderActor.generated.h"

/**
 * 
 */
UCLASS()
class FIT3094_A2_CODE_API ABuilderActor : public AGOAPActor
{
	GENERATED_BODY()
protected:
	virtual void BeginPlay() override;
public:
	ABuilderActor();
	virtual  void Tick(float DeltaSeconds) override;
	TMap<FString, bool>getWorldStates() override;
	TMap<FString, bool> createGoalState() override;

	int woodNum;
	int stoneNum;
	int64 Timer = 1;
	int64 TargetTime = TargetTime = FDateTime::UtcNow().ToUnixTimestamp() + Timer;;
};
