// Fill out your copyright notice in the Description page of Project Settings.


#include "PickupBuilderResource.h"
#include "GOAPActor.h"
#include "VillageCentreActor.h"
#include "BuilderActor.h"
#include "Kismet/KismetSystemLibrary.h"

PickupBuilderResource::PickupBuilderResource()
{
	reset();
	// all action except get food has same priority
	priority = 1;
}

PickupBuilderResource::~PickupBuilderResource()
{
}
bool PickupBuilderResource::isActionDone()
{
	if (treeGathered >= treeToGather && stoneGathered >=stoneToGather)
	{
		return true;
	}
	return false;
}

bool PickupBuilderResource::checkProceduralPrecondition(AGOAPActor* Agent)
{
	if (villageListArray.Num() == 0)
	{
		TArray<AActor*> mOverlaps;
		TArray<AActor*> mIgnores;

		TArray<TEnumAsByte<EObjectTypeQuery>>objectTypes;
		objectTypes.Add(UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_GameTraceChannel1));

		UKismetSystemLibrary::SphereOverlapActors(Agent->GetWorld(), Agent->GetActorLocation(), 5000.f, objectTypes, NULL, mIgnores, mOverlaps);

		for (auto actor : mOverlaps)
		{
			AVillageCentreActor* villageCentre = Cast<AVillageCentreActor>(actor);
			if (villageCentre)
			{
				villageListArray.Add(villageCentre);
			}
		}
	}

	AVillageCentreActor* nearestVillage = nullptr;
	for (auto tree : villageListArray)
	{
		if (nearestVillage)
		{
			if (FVector::Dist(tree->GetActorLocation(), Agent->GetActorLocation()) < FVector::Dist(nearestVillage->GetActorLocation(), Agent->GetActorLocation()))
			{
				nearestVillage = tree;
			}

		}
		else
		{
			nearestVillage = tree;
		}
	}
	if (nearestVillage)
	{
		target = nearestVillage;
		return true;
	}
	return false;
}


bool PickupBuilderResource::performAction(AGOAPActor* Agent)
{
	AVillageCentreActor* village = Cast<AVillageCentreActor>(target);
	ABuilderActor* builder = Cast<ABuilderActor>(Agent);

	if (!village || !builder)
	{
		return false;
	}
	if(builder->health<=builder->healthThreshold)
	{
		return false;
	}
	if (FDateTime::UtcNow().ToUnixTimestamp() > TargetTime)
	{

		
		if (village->getWoodResource() > 0 || village->getStoneResource() > 0)
		{


				if (village->getWoodResource() >0 && builder->woodNum <10)
				{
					builder->woodNum += 1;
					treeGathered = builder->woodNum;

					village->setWoodResource(-1);
					TargetTime = FDateTime::UtcNow().ToUnixTimestamp() + Timer;


				}
				if(village->getStoneResource() >0 && builder->stoneNum <5)
				{
					builder->stoneNum += 1;
					stoneGathered = builder->stoneNum;

					village->setWoodResource(-1);
					TargetTime = FDateTime::UtcNow().ToUnixTimestamp() + Timer;
				}


		}


		



	}
	return true;
}

bool PickupBuilderResource::requiresInRange()
{
	return true;
}

void PickupBuilderResource::reset()
{
	setInRange(false);
	target = nullptr;
	treeGathered = 0;
	stoneGathered = 0;
	TargetTime = FDateTime::UtcNow().ToUnixTimestamp() + Timer;

}