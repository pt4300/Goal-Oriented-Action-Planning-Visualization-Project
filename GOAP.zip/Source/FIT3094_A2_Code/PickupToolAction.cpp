// Fill out your copyright notice in the Description page of Project Settings.


#include "PickupToolAction.h"
#include "WoodCuter.h"
#include "Stonemason.h"
#include "Kismet/KismetSystemLibrary.h"

PickupToolAction::PickupToolAction()
{
	reset();
	// pickup tool should have higher priority than resource gathering but less than food eating
	priority = 2;
}

PickupToolAction::~PickupToolAction()
{
}

bool PickupToolAction::isActionDone()
{
	if (toolPickedUp)
	{
		return true;
	}
	return false;
}

bool PickupToolAction::checkProceduralPrecondition(AGOAPActor* Agent)
{
	if (villageListArray.Num() == 0)
	{
		TArray<AActor*> mOverlaps;
		TArray<AActor*> mIgnores;

		TArray<TEnumAsByte<EObjectTypeQuery>>objectTypes;
		objectTypes.Add(UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_GameTraceChannel1));

		UKismetSystemLibrary::SphereOverlapActors(Agent->GetWorld(), Agent->GetActorLocation(), 5000.f, objectTypes, NULL, mIgnores, mOverlaps);

		for (auto actor : mOverlaps)
		{
			AVillageCentreActor* villageCentre = Cast<AVillageCentreActor>(actor);
			if (villageCentre)
			{
				villageListArray.Add(villageCentre);
			}
		}
	}

	AVillageCentreActor* nearestVillage = nullptr;
	for (auto tree : villageListArray)
	{
		if (nearestVillage)
		{
			if (FVector::Dist(tree->GetActorLocation(), Agent->GetActorLocation()) < FVector::Dist(nearestVillage->GetActorLocation(), Agent->GetActorLocation()))
			{
				nearestVillage = tree;
			}

		}
		else
		{
			nearestVillage = tree;
		}
	}
	if (nearestVillage)
	{
		target = nearestVillage;
		return true;
	}
	return false;
}


bool PickupToolAction::performAction(AGOAPActor* Agent)
{
	AVillageCentreActor* village = Cast<AVillageCentreActor>(target);
	AWoodCuter* woodCuter = Cast<AWoodCuter>(Agent);
	AStonemason* stonemason = Cast<AStonemason>(Agent);

	if (!village)
	{
		return false;
	}
	if (FDateTime::UtcNow().ToUnixTimestamp() > TargetTime)
	{



			if(woodCuter)
			{
				if(village->getToolResource()>0 && !woodCuter->hasTool)
				{
					village->setTools(-1);
					woodCuter->hasTool = true;
					woodCuter->toolDur = 75;
					toolPickedUp = true;
				}
				else
				{// wait for tool to be deliver
					return false;
				}
				TargetTime = FDateTime::UtcNow().ToUnixTimestamp() + Timer;

			}
			else if (stonemason)
			{
				if(village->getToolResource()>0 && !stonemason->hasTool)
				{
					village->setTools(-1);
					stonemason->hasTool = true;
					stonemason->toolDur = 75;
					toolPickedUp = true;
				}
				else
				{
					return false;
				}
				
				TargetTime = FDateTime::UtcNow().ToUnixTimestamp() + Timer;


			}
			else
			{
				// reschedule action if incorrect type agent pick tool
				return false;
			}




		


	}
	return true;
}

bool PickupToolAction::requiresInRange()
{
	return true;
}

void PickupToolAction::reset()
{
	setInRange(false);
	target = nullptr;
	toolPickedUp = false;
	
	TargetTime = FDateTime::UtcNow().ToUnixTimestamp() + Timer;

}